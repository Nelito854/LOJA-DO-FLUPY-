// PÁGINA INICIAL: lista de APKs, categorias e busca (aceita ?q= e ?cat= na URL)
document.addEventListener("DOMContentLoaded", () => {
  document.title = CONFIG.nomeSite;
  const main = document.getElementById("main");
  const busca = document.getElementById("busca");
  const params = new URLSearchParams(location.search);
  const categorias = ["Todos", ...new Set(APPS.map(a => a.categoria))];
  let categoria = params.get("cat") || "Todos";
  busca.value = params.get("q") || "";

  const cartao = a => `
    <article class="card">
      <a href="app.html?id=${a.id}"><img src="${a.icone}" alt="Ícone de ${a.nome}"></a>
      <div class="info">
        <a class="nome" href="app.html?id=${a.id}">${a.nome}</a>
        <small>${a.desenvolvedor}</small>
        <small>★ ${a.nota} · ${a.tamanho}</small>
        <a class="btn" href="${a.link}" target="_blank" rel="noopener">Baixar</a>
      </div>
    </article>`;

  function desenhar() {
    const termo = busca.value.trim().toLowerCase();
    const lista = APPS.filter(a =>
      (categoria === "Todos" || a.categoria === categoria) &&
      `${a.nome} ${a.desenvolvedor}`.toLowerCase().includes(termo));
    const destaques = APPS.filter(a => a.destaque);

    main.innerHTML = `
      <p class="dev">${CONFIG.slogan}</p>
      <div class="chips">${categorias.map(c =>
        `<button class="chip ${c === categoria ? "ativo" : ""}" data-cat="${c}">${c}</button>`).join("")}</div>
      ${categoria === "Todos" && !termo ? `<h3 class="sub">⭐ Em destaque</h3>
        <div class="grade">${destaques.map(cartao).join("")}</div>` : ""}
      <h3 class="sub">${categoria} · ${lista.length} APK(s)</h3>
      <div class="grade">${lista.map(cartao).join("") || "<p>Nenhum APK encontrado.</p>"}</div>`;

    main.querySelectorAll(".chip").forEach(b =>
      b.onclick = () => { categoria = b.dataset.cat; desenhar(); });
  }

  busca.addEventListener("input", desenhar);
  desenhar();
});
