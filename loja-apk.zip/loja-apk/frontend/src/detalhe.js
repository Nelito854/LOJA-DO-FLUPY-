// PÁGINA DO APK: mostra os dados do app escolhido (lê ?id=... da URL)
document.addEventListener("DOMContentLoaded", () => {
  const main = document.getElementById("main");
  const id = new URLSearchParams(location.search).get("id");
  const a = APPS.find(x => x.id === id);

  if (!a) {
    document.title = "APK não encontrado - " + CONFIG.nomeSite;
    main.innerHTML = `<section class="caixa"><h2>APK não encontrado</h2><a href="index.html">← Voltar para a loja</a></section>`;
    return;
  }

  document.title = `${a.nome} - ${CONFIG.nomeSite}`;
  main.innerHTML = `
    <section class="detalhe">
      <img class="icone-grande" src="${a.icone}" alt="Ícone de ${a.nome}">
      <div>
        <h2>${a.nome}</h2>
        <p class="dev">${a.desenvolvedor} · ${a.categoria}</p>
        <p>★ ${a.nota} · ${a.downloads} downloads</p>
        <a class="btn grande" href="${a.link}" target="_blank" rel="noopener">⬇ Baixar APK ${a.versao}</a>
        <p class="aviso">${CONFIG.aviso}</p>
      </div>
    </section>
    ${a.prints && a.prints.length ? `
      <h3 class="sub">Imagens</h3>
      <div class="prints">${a.prints.map(p => `<img src="${p}" alt="Print de ${a.nome}">`).join("")}</div>` : ""}
    <h3 class="sub">Sobre este APK</h3>
    <p class="caixa">${a.descricao}</p>
    <h3 class="sub">Informações</h3>
    <table class="info-tab">
      <tr><td>Versão</td><td>${a.versao}</td></tr>
      <tr><td>Tamanho</td><td>${a.tamanho}</td></tr>
      <tr><td>Requisito</td><td>${a.android}</td></tr>
      <tr><td>Atualizado em</td><td>${a.atualizado}</td></tr>
      <tr><td>Pacote</td><td>${a.pacote}</td></tr>
    </table>`;
});
