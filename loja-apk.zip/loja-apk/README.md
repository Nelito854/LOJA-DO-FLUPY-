# Loja APK: base do site

Site estático (HTML, CSS e JavaScript). Não precisa instalar nada.

## Abrir no VS Code
1. Arquivo > Abrir Pasta > escolha a pasta `loja-apk`.
2. Instale a extensão **Live Server**, abra `frontend/index.html` e clique em **Go Live** (canto inferior direito).
   Ou dê dois cliques no `index.html` para abrir direto no navegador.

## Estrutura
```
frontend/
├── index.html        página inicial (busca, categorias, destaques, lista)
├── app.html          página de cada APK (abre com ?id=...)
├── suporte.html      contato e como instalar
├── config.js         nome, cor, logo, contatos e aviso do site
├── sidebar.js        menu lateral e topo (monta o layout de todas as páginas)
├── sidebar.css       estilo do menu lateral
├── src/
│   ├── apps.js       LISTA DE APKs: é aqui que você adiciona apps
│   ├── home.js       lógica da página inicial
│   └── detalhe.js    lógica da página de cada APK
└── assets/
    ├── style.css     estilo geral
    ├── icons/        ícones dos APKs
    └── img/          logo e prints (imagens da página)
```

## Adicionar um APK
Copie um bloco `{ ... }` de `frontend/src/apps.js`, troque os dados e salve (depois atualize o navegador com F5):
- `id`: único, sem espaços (aparece na URL da página)
- `icone`: caminho do ícone, como `assets/icons/meuapp.png`, ou o link de uma imagem
- `link`: link direto do arquivo .apk (é o botão Baixar)
- `prints`: imagens da página de detalhes (pode deixar `[]`)
- `destaque`: `true` mostra o app em "Em destaque"

Nova categoria: basta escrever um nome novo em `categoria`. O menu e os filtros são criados sozinhos.

## Personalizar
- Nome, cor, logo, contatos e aviso: `config.js`
- Visual (cores, cards, botões): `assets/style.css` e `sidebar.css`
- Nova página: copie `suporte.html`, troque o conteúdo e adicione o item no menu dentro de `sidebar.js`.
